Select nombre from producto;

Select nombre, precio from producto;

Select * from producto;

Select nombre as "nombre producto" , precio*0.084 as "euros", precio*0.050 as "dolares" from producto;

Select UPPER (nombre), precio from producto;

Select LOWER (nombre), precio from producto;

Select UPPER(SUBSTRING(nombre, 1, 2)) from fabricante;

Select nombre, ROUND(precio) from producto;

Select nombre, FLOOR(precio) from producto;


